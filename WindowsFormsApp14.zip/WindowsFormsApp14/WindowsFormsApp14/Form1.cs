﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
            private int[,] matrix;
            private void button1_Click(object sender, EventArgs e)
            {
                int rows = Convert.ToInt32(textBox1.Text);
                int cols = Convert.ToInt32(textBox2.Text);
                matrix = new int[rows, cols];
            }

            private void button2_Click(object sender, EventArgs e)
            {
            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    textBox3.AppendText(matrix[i, j] + " ");
                }
                textBox3.AppendText(Environment.NewLine);
            }
        }

            private void button3_Click(object sender, EventArgs e)
            {
            int startRow = Convert.ToInt32(textBox4.Text);
            int endRow = Convert.ToInt32(textBox5.Text);
            int startCol = Convert.ToInt32(textBox6.Text);
            int endCol = Convert.ToInt32(textBox7.Text);
            for (int i = startRow; i <= endRow; i++)
            {
                for (int j = startCol; j <= endCol; j++)
                {
                    textBox3.AppendText(matrix[i, j] + " ");
                }
                textBox3.AppendText(Environment.NewLine);
            }
        }

            private void button4_Click(object sender, EventArgs e)
            {
            int rows = Convert.ToInt32(textBox1.Text);
            int cols = Convert.ToInt32(textBox2.Text);
            int[,] newMatrix = new int[rows, cols]; 
            int minRows = Math.Min(rows, matrix.GetLength(2));
            int minCols = Math.Min(cols, matrix.GetLength(2));
            for (int i = 0; i < minRows; i++)
            {
                for (int j = 0; j < minCols; j++)
                {
                    newMatrix[i, j] = matrix[i, j]; 
                }
            }
            matrix = newMatrix;
        }
        }
    }

